a = [ [0] , [0,1] , [1] ,[2,3] ,[2] ,[4,5] , [1,4] ,[6,7]]
b = [[0,1,4,5],[2,3] ,[6,7]]
c=[]
flag = 1


def oh(a):
    for i in range(0,len(a)):
        for j in range(0,len(a)):
            if i != j:
                for k in a[i]:
                    if k in a[j]:
                        a[i] = list(set(a[i]).union(set(a[j])))
                        del a[j]
                        return 1,a
    return 0,a

while(flag):
    flag,a = oh(a)


print(a)