from cv2 import cv2 as cv
import numpy as np

def find_value(image,threshold):
    biggersum = 0
    smallersum = 0
    # a,b = image.shape
    # for i in range(0,a):
    #     for j in range(0,b):
    #         if image[i,j] >= threshold:
    #             x = x + 1
    #             biggersum = biggersum + image[i,j]
    #         else:
    #             y = y + 1
    #             smallersum = smallersum + image[i,j]
    biggersum = np.mean(np.ma.masked_greater_equal(image,threshold))
    smallersum = np.mean(np.ma.masked_less(image,threshold))
    # value = ( biggersum/x + smallersum/y )/2
    value = (biggersum+smallersum)/2
    return value

def image_change(image,value):
    a,b = image.shape
    for i in range(0,a):
        for j in range(0,b):
            if image[i,j] >= value:
                image[i,j] = 0
            else:
                image[i,j] = 255
    return image

def find_threshold(image, threshold):
    thrlist = []
    while(1):
        thrlist.append(threshold)
        value = find_value(image,threshold)
        value = round(value)
        if (abs(threshold - value) >=1):
            threshold = value
        else:
            break
    return thrlist

def median(image,size):
    a,b = image.shape
    f_size = (size-1)/2
    f_size = int(f_size)
    new_image = np.array(image,copy = True)
    for i in range(0,a-size):
        for j in range(0,b-size):
            value = []
            for m in range(i,i+size):
                for n in range(j,j+size):
                    value.append(image[m,n])
            value = sorted(value)
            index = (size*size + 1)/2
            index = int(index)
            new_image[i+f_size,j+f_size] = value[index]
    return new_image

def check_neighbor(image,m,n):
    neighbor_pixels = []
    for i in range(n-1,n+2): #check the three pixels above image[m,n]
        if image[m - 1,i] > 1:
            neighbor_pixels.append(int(image[m - 1,i]))
    if image[m,n-1] > 1:
        neighbor_pixels.append(int(image[m,n - 1]))# check the two pixels beside image[m,n]
    if image[m,n+1] > 1:
        neighbor_pixels.append(int(image[m,n + 1]))
    if len(neighbor_pixels) >= 1:
        neighbor_pixels = sorted(neighbor_pixels)
        return neighbor_pixels[0],neighbor_pixels # find the minimum lable except 0
    return 0,neighbor_pixels

def neighbors(nlist,tmp):
    if len(tmp) > 1:
        tmp = list(set(tmp))
    if tmp not in nlist:
        nlist.append(tmp)
    return nlist
    
    



def two_pass(image,n):
    lable = 1
    n = int((n + 1)/2)
    #lable = int(lable)
    neighbor_list = []
    a,b = image.shape
    lable_image = np.zeros((a,b))
    for i in range(n,a-n):
        for j in range(n,b-n):
            if image[i,j] == 0:
                flag,neighbor_pixels = check_neighbor(lable_image,i,j)
                if flag == 0:
                    lable = lable + 1
                    lable_image[i,j] = lable
                    neighbor_pixels.append(lable)
                    neighbor_list = neighbors(neighbor_list,neighbor_pixels)
                else:
                    lable_image[i,j] = flag
                    neighbor_list = neighbors(neighbor_list,neighbor_pixels)
                    
    return lable_image,neighbor_list


def combine(a):
    for i in range(0,len(a)):
        for j in range(0,len(a)):
            if i != j:
                for k in a[i]:
                    if k in a[j]:
                        a[i] = list(set(a[i]).union(set(a[j])))
                        del a[j]
                        return 1,a
    return 0,a

image_a = cv.imread('rice_img7.png',0)

threshold = 100
thrlist = find_threshold(image_a,threshold)
print(thrlist)


value = thrlist[-1]
image = image_change(image_a,value)
n = 5
image = median(image,n)
lable_image ,neighbor_list = two_pass(image,n)

cv.imshow('threshold value = %d'%(thrlist[-1]),image)
cv.imshow('lable imgae',lable_image)
# num = count_rice(lable_image)
flag = 1
while(flag):
    flag,neighbor_list = combine(neighbor_list)

print(neighbor_list)
print(len(neighbor_list))
#num = count_rice

        
cv.waitKey(0)



