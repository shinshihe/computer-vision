from cv2 import cv2 as cv
import numpy as np

def find_value(image,threshold):
    biggersum = 0
    smallersum = 0
    biggersum = np.mean(np.ma.masked_greater_equal(image,threshold))
    smallersum = np.mean(np.ma.masked_less(image,threshold))
    value = (biggersum+smallersum)/2
    return value

def image_change(image,value):
    a,b = image.shape
    for i in range(0,a):
        for j in range(0,b):
            if image[i,j] >= value:
                image[i,j] = 0
            else:
                image[i,j] = 255
    return image

def find_threshold(image, threshold):
    thrlist = []
    while(1):
        thrlist.append(threshold)
        value = find_value(image,threshold)
        value = round(value)
        if (abs(threshold - value) >=1):
            threshold = value
        else:
            break
    return thrlist

def median(image,size):
    a,b = image.shape
    f_size = (size-1)/2
    f_size = int(f_size)
    new_image = np.array(image,copy = True)
    for i in range(0,a-size):
        for j in range(0,b-size):
            value = []
            for m in range(i,i+size):
                for n in range(j,j+size):
                    value.append(image[m,n])
            value = sorted(value)
            index = (size*size + 1)/2
            index = int(index)
            new_image[i+f_size,j+f_size] = value[index]
    return new_image

def check_neighbor(image,m,n):
    neighbor_pixels = []
    for i in range(n-1,n+2): #check the three pixels above image[m,n]
        if image[m - 1,i] > 1:
            neighbor_pixels.append(int(image[m - 1,i]))
    if image[m,n-1] > 1:
        neighbor_pixels.append(int(image[m,n - 1]))# check the two pixels beside image[m,n]
    if image[m,n+1] > 1:
        neighbor_pixels.append(int(image[m,n + 1]))
    if len(neighbor_pixels) >= 1:
        neighbor_pixels = sorted(neighbor_pixels)
        return neighbor_pixels[0],neighbor_pixels # find the minimum lable except 0
    return 0,neighbor_pixels

def neighbors(nlist,tmp):
    if len(tmp) > 1:
        tmp = list(set(tmp))
    if tmp not in nlist:
        nlist.append(tmp)
    return nlist
    
    



def two_pass(image,n):
    lable = 1
    n = int((n + 1)/2)
    #lable = int(lable)
    neighbor_list = []
    a,b = image.shape
    lable_image = np.zeros((a,b))
    for i in range(n,a-n):
        for j in range(n,b-n):
            if image[i,j] == 0:
                flag,neighbor_pixels = check_neighbor(lable_image,i,j)
                if flag == 0:
                    lable = lable + 1
                    lable_image[i,j] = lable
                    neighbor_pixels.append(lable)
                    neighbor_list = neighbors(neighbor_list,neighbor_pixels)
                else:
                    lable_image[i,j] = flag
                    neighbor_list = neighbors(neighbor_list,neighbor_pixels)
                    
    return lable_image,neighbor_list


def combine(a):
    for i in range(0,len(a)):
        for j in range(0,len(a)):
            if i != j:
                for k in a[i]:
                    if k in a[j]:
                        a[i] = list(set(a[i]).union(set(a[j])))
                        del a[j]
                        return 1,a
    return 0,a
def twopass_steptwo(image,lista,n):
    n =int((n + 1)/2)
    a,b = image.shape
    for i in range(0,n):
        for j in range(0,b):
            image[i,j] = 0
    for i in range(a-n,a):
        for j in range(0,b):
            image[i,j] = 0
    for j in range(0,n):
        for i in range(0,a):
            image[i,j] = 0
    for j in range(b-n,b):
        for i in range(0,a):
            image[i,j] = 0
    # change the lables on the edges to zero

    for i in range(n,a-n):
        for j in range(n,b-n):
            if image[i,j] > 1:
                for k in lista:
                    if image[i,j] in k:
                        image[i,j] = k[0]
                        break
    return image

def lable_list(lable_image):
    a,b = lable_image.shape
    tmp = []
    for i in range(0,a):
        for j in range(0,b):
            if (lable_image[i][j] > 0 and lable_image[i][j] not in tmp):
                tmp.append((lable_image[i][j]))
    return tmp

def full_rice(lable_image,lables):
    lable_num = []
    damaged_rice = []
    x_value,y_value = np.where(lable_image > 1)
    average_size = int(2/3 * len(x_value)/rice_num)
    print('average_size',average_size)
    for i in lables:
        x_value,y_value = np.where(lable_image == i)
        lable_num.append(len(x_value))
    for i in range(0,len(lable_num)):
        if lable_num[i] < average_size:
            damaged_rice.append(lables[i])
    for i in damaged_rice:
        lables.remove(i)
    return lables

def full_rice_im(lables,image):
    a,b = image.shape
    new_image = np.zeros((a,b))
    for i in lables:
        x_value,y_value = np.where(image == i)
        for j in range(0,len(x_value)):
            new_image[x_value[j],y_value[j]] = 100
    return new_image

image_a = cv.imread('rice_img7.png',0)
threshold = 100
thrlist = find_threshold(image_a,threshold)
print(thrlist)
value = thrlist[-1]
image = image_change(image_a,value)
n = 5
image = median(image,n)
lable_image ,neighbor_list = two_pass(image,n)

cv.imshow('threshold value = %d'%(thrlist[-1]),image)
# cv.imshow('lable imgae',lable_image)
# num = count_rice(lable_image)
flag = 1
while(flag):
    flag,neighbor_list = combine(neighbor_list)

rice_num = len(neighbor_list)


# change all the lables which are connected to the same value
lable_image = twopass_steptwo(lable_image,neighbor_list,n)

# labels are the final values left in lable image
lables = lable_list(lable_image)

full_rice_lables = full_rice(lable_image,lables)
full_rice_image = full_rice_im(full_rice_lables,lable_image)

# cv.imshow('shit',lable_image)
cv.imshow('full_rice',full_rice_image)
# print(lables)








# task3
cv.waitKey(0)
