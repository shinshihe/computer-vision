import os
from cv2 import cv2 as cv
path = 'haha'
if not os.path.exists(path):
    os.mkdir(path)
path = path + '/' + 'shit.png'
tmp = cv.imread('rice_img1.png',0)
# cv.imshow('haha',tmp)
# cv.imwrite(path,tmp)
a = 'abc/def/image1.png'
cv.waitKey(0)
